﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Program
    {
        const string USER_SYMBOL = "X";
        const string COMPUTER_SYMBOL = "O";
        const string EMPTY = "";

        const int SIZE = 3;

        // constants for the 2 diagonals
        const int TOP_LEFT_TO_BOTTOM_RIGHT = 1;
        const int TOP_RIGHT_TO_BOTTOM_LEFT = 2;

        // constants for IsWinner
        const int NONE = -1;
        const int ROW = 1;
        const int COLUMN = 2;
        const int DIAGONAL = 3;

        static void Main(string[] args)
        {

            int row = -1, column = -1;
            int winningDimension, winningValue;
            bool playersTurn = false;

            /*
            declare the rectangular array board and set it equal to the value returned from CreateBoard

            do
            {
                set playersTurn to the opposite of what it is now
                Call DrawBoard
                if it's the players turn
                    Display a message
                    Call GetRowAndColumn
                    set the cell on the board at row, column = users symbol
                else
                    Display a message
                    You might want to pause here
                    Call GetComputerRowAndColumn
                    set the cell on the board at row, column = users symbol
                }
                Call DrawBoard
            }
            while ( no one has won yet );
            You might want to pause here
            if it's the players turn 
                display a message that they just won
            else
                display a message that the computer won
            */

            Console.ReadLine();
        }

        static string[,] CreateBoard()
        {
            string[,] board = new string[SIZE, SIZE];
            /*
             * for row = 0 to size - 1
             *      for column = 0 to size - 1
             *          set the value in the cell at row, column to EMPTY
             *      end for column
             *  end for row
            */
            return board;
        }

        // generic method that gets an integer in the specified range from the user
        static int GetInt(string label, int min, int max)
        {
            bool isInt = false;
            int number = min - 1;
            do
            {
                Console.Write(String.Format("Please enter a whole number between {0} and {1} for {2}: ", min, max, label));
                string input = Console.ReadLine();
                isInt = int.TryParse(input, out number);
            } while (!(isInt && number >= min && number <= max));

            return number;
        }

        static void GetRowAndColumn(string[,] board, ref int row, ref int column)
        {
            /*
            do
                // get the row from the user
                // get the column from the user
            while (the cell at row, column isn't empty);
            */
        }

        static void GetComputerRowAndColumn(string[,] board, ref int row, ref int column)
        {
            /*
            do
                // randomly generate the row
                // randomly generate the column
            while (the cell at row, column isn't empty);
            */
        }

        // This method takes a row (in the range of 0 - 4) and returns true if 
        // the row on the form contains 5 Xs or 5 Os.
        // Use it as a model for writing IsColumnWinner
        static bool IsRowWinner(string[,] board, int row)
        {
            string symbol = board[row, 0];
            for (int col = 1; col < SIZE; col++)
            {
                if (symbol == EMPTY || board[row, col] != symbol)
                    return false;
            }
            return true;
        }

        static bool IsColumnWinner(string[,] board, int col)
        {
            return true;
        }

        static bool IsDiagonal1Winner(string[,] board)
        {
            // the row and the column are both the same on diagonal 1
            return true;
        }

        static bool IsDiagonal2Winner(string[,] board)
        {
            // the row gets bigger as the column gets smaller on diagonal 2
            return true;
        }

        static bool IsFull(string[,] board)
        {
            /*
             * for row = 0 to size - 1
             *      for column = 0 to size - 1
             *          if the cell at row, column is empty
             *              return false
             *      end for column
             *  end for row
            */
            return true;
        }

        // This method determines if any row, column or diagonal on the board is a winner.
        // It returns true or false and the output parameters will contain appropriate values
        // when the method returns true.  See constant definitions at top of the file.
        static bool IsWinner(string[,] board, out int whichDimension, out int whichOne)
        {
            // rows
            for (int row = 0; row < SIZE; row++)
            {
                if (IsRowWinner(board, row))
                {
                    whichDimension = ROW;
                    whichOne = row;
                    return true;
                }
            }
            // columns
            for (int column = 0; column < SIZE; column++)
            {
                if (IsColumnWinner(board, column))
                {
                    whichDimension = COLUMN;
                    whichOne = column;
                    return true;
                }
            }
            // diagonals
            if (IsDiagonal1Winner(board))
            {
                whichDimension = DIAGONAL;
                whichOne = TOP_LEFT_TO_BOTTOM_RIGHT;
                return true;
            }
            if (IsDiagonal2Winner(board))
            {
                whichDimension = DIAGONAL;
                whichOne = TOP_RIGHT_TO_BOTTOM_LEFT;
                return true;
            }
            whichDimension = NONE;
            whichOne = NONE;
            return false;
        }

        // I wrote this method to show you how to call IsWinner
        static bool IsTie(string[,] board)
        {
            int winningDimension, winningValue;
            return (IsFull(board) && !IsWinner(board, out winningDimension, out winningValue));
        }

        // this method can be used to pause
        static void Pause()
        {
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(2));
        }

        // these 2 methods can be used for drawing the board on the screen
        // center is called by DrawBoard
        static String Center(String text, int len)
        {
            if (len <= text.Length)
                return text.Substring(0, len);
            int before = (len - text.Length) / 2;
            int after = len - text.Length - before;
            return new String(' ', before) + text + new String(' ', after);
        }

        static void DrawBoard(string[,] board)
        {
            Console.Clear();
            int index = 0;
            string top = ".=============";
            string second = "|             ";
            string middle = "|";
            string output;
            ConsoleColor defaultColor = Console.ForegroundColor;

            // column headings
            Console.Write(Center(top, 4));
            for (int c = 0; c < SIZE; c++)
                Console.Write(top);
            Console.Write(".\n");
            Console.Write(Center(second, 4));
            for (int c = 0; c < SIZE; c++)
            {
                output = Center(c.ToString(), 13);
                Console.Write(middle + output);
            }
            Console.Write("|\n");

            for (int r = 0; r < SIZE; r++)
            {
                Console.Write(Center(top, 4));
                for (int c = 0; c < SIZE; c++)
                    Console.Write(top);
                Console.Write(".\n");

                Console.Write(Center(second, 4));
                for (int c = 0; c < SIZE; c++)
                    Console.Write(second);
                Console.Write("|\n");

                Console.Write(middle + Center(r.ToString(), 3));
                for (int c = 0; c < SIZE; c++)
                {
                    output = Center(board[r, c], 13);
                    Console.Write(middle + output);
                    index++;
                }
                Console.Write("|\n");

                Console.Write(Center(second, 4));
                for (int c = 0; c < SIZE; c++)
                    Console.Write(second);
                Console.Write("|\n");
            }
            Console.Write(Center(top, 4));
            for (int c = 0; c < SIZE; c++)
                Console.Write(top);
            Console.Write(".\n");
        }
    }
}
